=== WP.com Site Helper ===
Contributors: lamosty, obenland, automattic
Tags: WP.com
Requires at least: 4.7
Tested up to: 4.7
Stable tag: trunk
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

A helper for connecting WordPress.com sites to external host infrastructure.

== Description ==

A helper for connecting WordPress.com sites to external host infrastructure.
