<?php
/**
 * Plugin Name: Footer optimizations
 * Plugin URI: http://wordpress.com
 * Description: WIP
 * Version: 1.0
 * @package jetpack
 * Author: Automattic
 * Author URI: http://automattic.com/
 */

require_once __DIR__ . '/footer-credit-optimizations.php';
require_once __DIR__ . '/footer-credit/footer-credit.php';

