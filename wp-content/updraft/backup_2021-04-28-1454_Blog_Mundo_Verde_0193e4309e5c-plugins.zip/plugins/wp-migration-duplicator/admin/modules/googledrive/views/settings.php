<?php
if ( ! defined( 'WPINC' ) ) {
    die;
}
?>
<div>
	<h3><?php _e('Google Drive','wp-migration-duplicator');?></h3>
</div>
<div class="wt_info_box" style="margin-bottom:35px;">
<ul style="list-style:disc; margin-left:20px;">
		<li><?php echo sprintf(wp_kses(__('Obtain client ID and client secret from the Google developer console to get connected to Google Drive. Refer Google developer <a href="%s" target="_blank">documentation</a>', 'wp-migration-duplicator'), array('a' => array('href' => array(), 'target' => array()))), esc_url('https://developers.google.com/drive/api/v3/about-auth')); ?></li>
		<li><?php _e('To update the credentials, kindly disconnect, update and authenticate.','wp-migration-duplicator'); ?></li>
	</ul>
</div>

<form method="post"  action="<?php echo esc_url($_SERVER["REQUEST_URI"]);?>" id="wt_mgdp_googledrive">
	<?php wp_nonce_field('wp_migration_duplicator_googledrive','_google_drive_auth'); ?>
	<input type="hidden" name="wt_authenticate_google_form">
	<table class="form-table wf-form-table">
		<tr>
			<th><label><?php _e("Client ID",'wp-migration-duplicator'); ?><span class="wt-mgdp-tootip" data-wt-mgdp-tooltip="<?php _e('The Client ID is a publicly exposed string that is used by the service API to identify the application, and is also used to build authorization URLs that are presented to users.', 'wp-migration-duplicator'); ?>"><span class="wt-mgdp-tootip-icon"></span></span></label></th>
			<td>
				<input type="text" name="wt_google_client_id" value="<?php echo $client_id; ?>">
			</td>
			<td></td>
		</tr>

		<tr>
		
			<th><label><?php _e("Client Secret",'wp-migration-duplicator'); ?><span class="wt-mgdp-tootip" data-wt-mgdp-tooltip="<?php _e('The Client Secret is used to authenticate the identity of the application to the service API when the application requests to access a user’s account.', 'wp-migration-duplicator'); ?>"><span class="wt-mgdp-tootip-icon"></span></span></label></th>
			<td>
				<input type="text" name="wt_google_client_secret" value="<?php echo $client_secret; ?>">
			</td>
			<td></td>
		</tr>
	</table>
	<div style="clear: both;"></div>
	<?php if( $authenticated === false ):?> 
		<div class="wf-plugin-toolbar wt-migrator-action-bar bottom wt-migrator-authenticate-bar">
			<div class="left">
			</div>
			<div class="right">
				<span class="wt-migrator-notice wt-migrator-notice-inline" style=" margin-top: 10px; display: inline-block; margin-right: -20px;"></span>
				<input type="submit" name="wt_authenticate_google" value="<?php _e('Authenticate', 'wp-migration-duplicator'); ?>" class="button button-primary" style="float:right;" />
				<span class="spinner" style="margin-top:11px"></span>
			</div>
		</div>
		<?php else :?>
			<div class="wf-plugin-toolbar bottom wt-migrator-action-bar wt-migrator-disconnect-bar">
			<div class="left">
			</div>
			<div class="right">
				<span class="wt-migrator-notice wt-migrator-notice-inline" style=" margin-top: 10px; display: inline-block; margin-right: -20px;"></span>
				<button type="submit" id="wt_disconnect_googledrive" name="wt_disconnect_googledrive" class="button button-primary" style="float:right;"><?php _e('Disconnect', 'wp-migration-duplicator'); ?></button>
				<span class="spinner" style="margin-top:11px"></span>
			</div>
		</div>
	<?php endif; ?>
</form>
