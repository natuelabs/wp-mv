( function( $ ) {

	$( '.swipebox' ).swipebox( {
		useCSS : true, // False will force the use of jQuery for animations
		useSVG : false, // False to force the use of png for buttons
	} );

} )( jQuery );
