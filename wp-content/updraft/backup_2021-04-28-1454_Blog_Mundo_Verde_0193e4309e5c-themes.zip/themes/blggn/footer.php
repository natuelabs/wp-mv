
<footer class="voss-footer">
	<?php get_template_part( 'parts/footer/footer', get_theme_mod( 'footer_layout', 'v1' ) ); ?>
</footer>

</div><!-- #main -->

<?php wp_footer(); ?>

</body>
</html>
