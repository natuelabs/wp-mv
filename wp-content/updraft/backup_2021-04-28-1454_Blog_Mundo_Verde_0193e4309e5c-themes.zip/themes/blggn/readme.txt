=== Theme ===
Contributors: Vossen
Requires at least: WordPress 4
Tested up to: WordPress 5.0
Tags: blog, e-commerce, one-column, two-columns, three-columns, left-sidebar, right-sidebar, grid-layout, custom-colors, custom-logo, footer-widgets, full-width-template, custom-menu, editor-style, featured-images, flexible-header, sticky-post, theme-options, translation-ready
License: Themeforest Licence
License URI: http://themeforest.net/licenses

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Click on the 'Upload Theme' button.
3. Click 'Choose File' > then find your theme zip file > Click the “Install Now” button.
4. Click on the 'Activate' button to use your new theme right away.
5. Go to http://vossen.ticksy.com for a guide on how to customize the theme.
6. Navigate to Appearance > Customize in your admin panel and customize to taste.
