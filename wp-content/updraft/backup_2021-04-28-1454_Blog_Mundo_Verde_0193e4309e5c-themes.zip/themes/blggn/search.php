<?php get_header(); ?>

	<?php get_template_part( 'parts/archive/archive-header' ); ?>
	<?php get_template_part( 'parts/post/content-archive' ); ?>

<?php get_footer(); ?>
